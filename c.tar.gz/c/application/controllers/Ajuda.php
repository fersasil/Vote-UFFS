<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajuda extends CI_Controller {
	public function index(){
        
            $this->load->view("backend/template/head");
            $this->load->view("backend/template/sidebar");
            $this->load->view("backend/help_pages/login");
            $this->load->view("backend/template/footer_end");
        }

    public function como_votar(){
        $this->load->view("backend/template/head");
        $this->load->view("backend/template/sidebar");
        $this->load->view("backend/template/topbar");

        $this->load->view("backend/help_pages/como_votar");
        $this->load->view("backend/template/footer_end");
    }

    public function como_funciona(){
        $this->load->view("backend/template/head");
        $this->load->view("backend/template/sidebar");
        $this->load->view("backend/template/topbar");

        $this->load->view("backend/help_pages/como_funciona");
        $this->load->view("backend/template/footer_end");
    }

    public function seguranca(){
        $this->load->view("backend/template/head");
        $this->load->view("backend/template/sidebar");
        $this->load->view("backend/template/topbar");

        $this->load->view("backend/help_pages/seguranca");
        
        $this->load->view("backend/template/footer_end");
    }

    public function fale_conosco(){
        $this->load->view("backend/template/head");
        $this->load->view("backend/template/sidebar");
        $this->load->view("backend/template/topbar");

        $this->load->view("backend/help_pages/fale_conosco");
        $this->load->view("backend/template/footer_end");
    }
}
