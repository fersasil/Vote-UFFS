<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function index(){
        
                $this->load->view("backend/template/head");
                $this->load->view("login/login");
                $this->load->view("backend/template/footer_end");
        }
}
